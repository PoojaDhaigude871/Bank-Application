package com.BankApplication.service;

import java.util.List;

import com.BankApplication.dto.AccountDto;
import com.BankApplication.entity.Account;



public interface AccountService {
	AccountDto createAccount(AccountDto account);


	AccountDto getAccountById(Long id);
	
	AccountDto deposit(long id,double amount);
	
	AccountDto withdraw(long id,double amount);
	
	List<AccountDto> getAllAccounts();
	
	void deleteAccount(long id);
}
