package com.BankApplication.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.BankApplication.dto.AccountDto;
import com.BankApplication.entity.Account;
import com.BankApplication.mapper.AccountMapper;
import com.BankApplication.repository.AccountRepository;
import com.BankApplication.service.AccountService;
@Service
public class AccountServiceImpl implements AccountService{

	
	private AccountRepository AR;
	
	
	public AccountServiceImpl(AccountRepository aR) {
		super();
		AR = aR;
	}


	@Override
	public AccountDto createAccount(AccountDto accountDto) {
		// TODO Auto-generated method stub
		
		Account account=AccountMapper.mapToAccount(accountDto);
		Account savedaccount=AR.save(account);
		return AccountMapper.mapToAccountDto(savedaccount) ;
	}


	@Override
	public AccountDto getAccountById(Long id) {
		// TODO Auto-generated method stub
		
		Account account=AR.findById(id).orElseThrow(()->new RuntimeException("Account does not exist"));
		
		return AccountMapper.mapToAccountDto(account);
	}


	@Override
	public AccountDto deposit(long id, double amount) {
		// TODO Auto-generated method stub
		Account account=AR.findById(id).orElseThrow(()->new RuntimeException("Account does not exist"));
		double totalbalance=account.getBalance()+amount;
		account.setBalance(totalbalance);
		Account savedaccount=AR.save(account);
		return AccountMapper.mapToAccountDto(savedaccount);
	}


	@Override
	public AccountDto withdraw(long id, double amount) {
		// TODO Auto-generated method stub
		
		Account account=AR.findById(id).orElseThrow(()->new RuntimeException("Account does not exist"));
		if(account.getBalance()<amount) {
			throw new RuntimeException("Insufficient Balance");
		}
		double totalbalance=account.getBalance()-amount;
		account.setBalance(totalbalance);
		Account savedaccount=AR.save(account);
		return AccountMapper.mapToAccountDto(savedaccount);
	}


	@Override
	public List<AccountDto> getAllAccounts() {
		// TODO Auto-generated method stub
		
		return AR.findAll().stream().map((account)-> AccountMapper.mapToAccountDto(account)).
		collect(Collectors.toList());
		//return null;
	}


	@Override
	public void deleteAccount(long id) {
		// TODO Auto-generated method stub
		Account account=AR.findById(id).orElseThrow(()->new 
				RuntimeException("Account does not exist"));
		AR.delete(account);
		
	}
	
	

}
