package com.BankApplication.mapper;

import com.BankApplication.dto.AccountDto;
import com.BankApplication.entity.Account;

public class AccountMapper {
	public static Account mapToAccount(AccountDto accountDto) {

	Account account=new Account(
			accountDto.getId(),
			accountDto.getAccountHolderName(),
			accountDto.getAccountNum(),
			accountDto.getBalance()
			);
	return account;
	
}


public static AccountDto mapToAccountDto (Account account) {
	AccountDto accountDto=new AccountDto(
			
			account.getId(),
			account.getAccountHolderName(),
			account.getAccountNum(),
			account.getBalance()
			
			);
	return accountDto;
}

}
