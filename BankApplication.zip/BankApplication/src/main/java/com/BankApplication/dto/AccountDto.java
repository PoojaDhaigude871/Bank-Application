package com.BankApplication.dto;

public class AccountDto {
	
	long id;
	String accountHolderName;
	long AccountNum;
	double balance;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public long getAccountNum() {
		return AccountNum;
	}
	public void setAccountNum(long accountNum) {
		AccountNum = accountNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public AccountDto(long id, String accountHolderName, long accountNum, double balance) {
		super();
		this.id = id;
		this.accountHolderName = accountHolderName;
		AccountNum = accountNum;
		this.balance = balance;
	}
	public AccountDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
