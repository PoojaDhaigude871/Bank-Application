import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Account } from './account';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http:HttpClient) { }

  private baseurl="http://localhost:8093/api/accounts"

  getAllAccount():Observable<Account[]>{
    return this.http.get<Account[]>(`${this.baseurl}`);
  }

  createAccount(account:Account):Observable<Account>{
    return this.http.post<Account>(`${this.baseurl}` ,account)

  }

  getAccountbyId(id:number):Observable<Account>{
    return this.http.get<Account>(`${this.baseurl}/${id}`)

  }
  deposit(id:number,amount:number):Observable<Account>{


    const request={amount};
    return this.http.put<Account>(`${this.baseurl}/${id}/deposit`,request)
  }
  Withdraw(id:number,amount:number){
    const request={amount}
    return this.http.put<Account>(`${this.baseurl}/${id}/withdraw`,request)

  }
}
