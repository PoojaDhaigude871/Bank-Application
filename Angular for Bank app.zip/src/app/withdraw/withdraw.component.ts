import { Component } from '@angular/core';
import { AccountService } from '../account.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Account } from '../account';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent {

  id:number=0
  accounts:Account=new Account();
  constructor(private as:AccountService,private route:ActivatedRoute,private router:Router){}

  ngOnInit(){
    this.id=this.route.snapshot.params["id"];
    this.as.getAccountbyId(this.id).subscribe(data=>{

      this.accounts=data;
    })

  }
  successmsg="";
  errormsg="";
  
  onSubmit(){
    if(this.isvalidamounts(this.accounts.balance)){
    this.as.Withdraw(this.id,this.accounts.balance).subscribe(data=>{
      this.accounts=data;

      this.successmsg="withdraw successfully.......!"

      setTimeout(()=>{

        this.router.navigate(['/account'])
      },1000)
      
    })
  }
  else{
    this.errormsg="Invalid amount please enter valid amount...."
    setTimeout(()=>{
      this.errormsg=""
    },1000)

  }}
  isvalidamounts(amount:number):boolean{
    return amount>0 && amount<100000000
  }

  }
