import { Component } from '@angular/core';
import { AccountService } from '../account.service';
import { Account } from '../account';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent {

  constructor(private accountService:AccountService,private router:Router){}
  accountCreate=false

  account:Account=new Account();

  onSubmit(){
    this.saveAccount();
  }

  saveAccount(){
    this.accountService.createAccount(this.account).subscribe(data=>{
      console.log(data);
      this.accountCreate=true;
      setTimeout(()=>{
        this.gotoaccount();

      },4000)
      
    })
  }

  gotoaccount(){
    this.router.navigate(['/account'])
  }

}
