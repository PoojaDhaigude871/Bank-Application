export class Account {
   
        id:number=0;
        accountHolderName:string="";
        accountNum:number=0;
        balance:number=0;
    }

